export interface Country {
  id: string; // 3-letter ISO code, e.g., "NLD", "DEU"
  dutchName: string;
  englishName: string;
}

export interface CountryDetails {
  continent: string;
  temperature: string;
  location: string;
  size: string;
  funFact: string;
  sources?: Array<{ title: string; url: string }>;
  source: string;
}

export type HintType = "continent" | "temperature" | "location" | "size";

export interface GameState {
  targetCountry: Country;
  selectedCountryId: string | null;
  isCorrect: boolean | null; // null = playing, true = Goed gedaan!, false = Helaas fout!
  hintOpen: boolean;
  activeHint: string | null;
  activeHintType: HintType | null;
  timerSeconds: number;
  isTimerRunning: boolean;
  scoreCorrect: number;
  scoreTotal: number;
}
