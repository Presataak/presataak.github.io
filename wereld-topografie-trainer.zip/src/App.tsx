import { useState, useEffect } from "react";
import { COUNTRIES, getRandomCountry } from "./countries";
import { Country, CountryDetails, GameState, HintType } from "./types";
import WorldMap from "./components/WorldMap";
import Stopwatch from "./components/Stopwatch";
import HintBox from "./components/HintBox";
import StatusScreens from "./components/StatusScreens";
import { HelpCircle, Check, MapPin, Award, BookOpen } from "lucide-react";

export default function App() {
  // 1. Core State
  const [targetCountry, setTargetCountry] = useState<Country>(() => getRandomCountry());
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null); // true = Goed gedaan, false = Helaas fout
  
  // 2. Hint State
  const [hintOpen, setHintOpen] = useState(false);
  const [activeHintType, setActiveHintType] = useState<HintType | null>(null);
  const [activeHintValue, setActiveHintValue] = useState<string | null>(null);
  const [hintLoading, setHintLoading] = useState(false);
  
  // 3. Score & Stopwatch State
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [scoreCorrect, setScoreCorrect] = useState(0);
  const [scoreTotal, setScoreTotal] = useState(0);

  // 4. API Details Cache
  const [cachedDetails, setCachedDetails] = useState<CountryDetails | null>(null);

  // Fetch Country Details in the background whenever the target country changes!
  useEffect(() => {
    setHintLoading(true);
    setCachedDetails(null);
    setActiveHintType(null);
    setActiveHintValue(null);

    fetch("/api/country-details", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        countryCode: targetCountry.id,
        dutchName: targetCountry.dutchName,
        englishName: targetCountry.englishName,
      }),
    })
      .then((res) => res.json())
      .then((data: CountryDetails) => {
        setCachedDetails(data);
        setHintLoading(false);
      })
      .catch((err) => {
        console.error("Fout bij laden van land details:", err);
        setHintLoading(false);
      });
  }, [targetCountry]);

  // Handle Hint button click: select one hint at random (stays the same for the entire round)
  const handleHintClick = () => {
    if (hintOpen) {
      setHintOpen(false);
      return;
    }

    setHintOpen(true);

    // If hint type has already been chosen for this round, don't change it!
    if (activeHintType && activeHintValue) return;

    // Pick a random hint category from the 4 requested:
    const hintCategories: HintType[] = ["continent", "temperature", "location", "size"];
    const randomCategory = hintCategories[Math.floor(Math.random() * hintCategories.length)];
    setActiveHintType(randomCategory);

    // Grab value from cached details or fall back to high-quality computed local guesses!
    let value = "";
    if (cachedDetails) {
      switch (randomCategory) {
        case "continent":
          value = cachedDetails.continent;
          break;
        case "temperature":
          value = cachedDetails.temperature;
          break;
        case "location":
          value = cachedDetails.location;
          break;
        case "size":
          value = cachedDetails.size;
          break;
      }
    }

    // Secondary fallback in case the API call didn't finish or failed
    if (!value) {
      // Local estimation rules for high availability
      if (randomCategory === "continent") {
        const euroIds = ["NLD", "DEU", "FRA", "BEL", "ESP", "ITA", "GBR", "PRT", "DNK", "NOR", "SWE", "FIN", "POL", "CHE", "AUT", "GRC", "TUR", "RUS", "UKR", "ISL"];
        const asiaIds = ["CHN", "IND", "JPN", "KOR", "IDN", "KAZ", "SAU", "IRN", "IRQ", "THA", "VNM", "MYS", "PHL", "PAK", "MNG"];
        const naIds = ["USA", "CAN", "MEX", "GRL"];
        const saIds = ["BRA", "ARG", "COL", "CHL"];
        const africaIds = ["ZAF", "EGY", "MAR", "KEN", "NGA", "MDG"];
        
        if (euroIds.includes(targetCountry.id)) value = "Europa";
        else if (asiaIds.includes(targetCountry.id)) value = "Azië";
        else if (naIds.includes(targetCountry.id)) value = "Noord-Amerika";
        else if (saIds.includes(targetCountry.id)) value = "Zuid-Amerika";
        else if (africaIds.includes(targetCountry.id)) value = "Afrika";
        else value = "Oceanië";
      } else if (randomCategory === "temperature") {
        const coldIds = ["NLD", "DEU", "BEL", "GBR", "DNK", "NOR", "SWE", "FIN", "POL", "CHE", "AUT", "CAN", "RUS", "ISL", "GRL", "MNG"];
        value = coldIds.includes(targetCountry.id) ? "koud" : "warm";
      } else if (randomCategory === "location") {
        const leftIds = ["USA", "CAN", "MEX", "GRL", "BRA", "ARG", "COL", "CHL"];
        const rightIds = ["CHN", "IND", "JPN", "KOR", "IDN", "AUS", "NZL", "THA", "VNM", "MYS", "PHL", "PAK", "MNG", "KAZ", "RUS"];
        if (leftIds.includes(targetCountry.id)) value = "links";
        else if (rightIds.includes(targetCountry.id)) value = "rechts";
        else value = "in het midden";
      } else if (randomCategory === "size") {
        // Precise size thresholds:
        // Large (>= 2.000.000 km2): USA, CAN, RUS, CHN, BRA, AUS, IND, ARG, KAZ, GRL, SAU
        const largeIds = ["USA", "CAN", "RUS", "CHN", "BRA", "AUS", "IND", "ARG", "KAZ", "GRL", "SAU"];
        // Small (< 500.000 km2): NLD, BEL, CHE, AUT, GRC, PRT, DNK, KOR, NZL, ISL, DEU, ITA, GBR, NOR, SWE, FIN, POL, JPN, MAR, IRQ, VNM, MYS, PHL
        const smallIds = ["NLD", "BEL", "CHE", "AUT", "GRC", "PRT", "DNK", "KOR", "NZL", "ISL", "DEU", "ITA", "GBR", "NOR", "SWE", "FIN", "POL", "JPN", "MAR", "IRQ", "VNM", "MYS", "PHL"];
        
        if (largeIds.includes(targetCountry.id)) {
          value = "groot (2.000.000 km² of groter)";
        } else if (smallIds.includes(targetCountry.id)) {
          value = "klein (kleiner dan 500.000 km²)";
        } else {
          value = "middelmatig (500.000 km² tot 2.000.000 km²)";
        }
      }
    }

    setActiveHintValue(value);
  };

  // Handle Controleer (Check) button click
  const handleCheckClick = () => {
    setIsTimerRunning(false); // Pause timer during review
    setScoreTotal((prev) => prev + 1);

    if (selectedCountry && selectedCountry.id === targetCountry.id) {
      setIsCorrect(true);
      setScoreCorrect((prev) => prev + 1);
    } else {
      setIsCorrect(false);
    }
  };

  // Action: Volgende Opdracht (Next country)
  const handleNextAssignment = () => {
    const next = getRandomCountry(targetCountry.id);
    setTargetCountry(next);
    setSelectedCountry(null);
    setIsCorrect(null);
    setHintOpen(false);
    setTimerSeconds(0);
    setIsTimerRunning(true);
  };

  // Action: Opnieuw Proberen (Retry same country)
  const handleRetrySame = () => {
    setSelectedCountry(null);
    setIsCorrect(null);
    setHintOpen(false);
    setTimerSeconds(0);
    setIsTimerRunning(true);
  };

  // Action: Andere Opdracht (Skip to another country)
  const handleOtherAssignment = () => {
    handleNextAssignment();
  };

  return (
    <div
      id="main-app-container"
      className="flex flex-col min-h-screen bg-[#202020] text-white overflow-x-hidden font-sans antialiased p-4 md:p-6 justify-between max-w-7xl mx-auto"
    >
      {/* 1. Header Area: Target Country Display Banner (TACTILE 3D CARD) */}
      <header id="app-header-container" className="w-full flex-shrink-0 mb-6">
        <div
          id="target-country-banner"
          className="bg-[#da8044] text-white text-center py-6 md:py-8 px-6 rounded-[40px] shadow-[0_12px_0_#b36430] border-4 border-[#202020] animate-in slide-in-from-top duration-500"
        >
          <span className="font-display text-xs md:text-sm font-black uppercase tracking-[4px] text-white/80 block mb-2">
            Waar ligt het land:
          </span>
          <h1
            id="target-country-name"
            className="font-display text-4xl md:text-7xl font-black uppercase tracking-tight"
          >
            {targetCountry.dutchName}
          </h1>
        </div>
      </header>

      {/* 2. Map Playground Area */}
      <main id="app-map-playground" className="flex-grow flex items-center justify-center relative min-h-[350px] md:min-h-[500px] mb-6">
        <div id="map-frame-wrapper" className="w-full h-full aspect-[16/9] max-h-[600px] relative">
          <WorldMap
            selectedCountryId={selectedCountry ? selectedCountry.id : null}
            onSelectCountry={setSelectedCountry}
            targetCountry={targetCountry}
          />

          {/* Closable Hint Box */}
          {hintOpen && (
            <HintBox
              hintType={activeHintType}
              hintValue={activeHintValue}
              loading={hintLoading}
              onClose={() => setHintOpen(false)}
              sources={cachedDetails?.sources}
            />
          )}

          {/* Correct & Incorrect Popups */}
          <StatusScreens
            isCorrect={isCorrect}
            targetCountry={targetCountry}
            clickedCountryName={selectedCountry ? selectedCountry.dutchName : null}
            details={cachedDetails}
            onNext={handleNextAssignment}
            onRetry={handleRetrySame}
            onOther={handleOtherAssignment}
          />
        </div>
      </main>

      {/* 3. Footer Control Bar Area */}
      <footer id="app-footer-controls" className="w-full flex-shrink-0">
        <div
          id="controls-row"
          className="grid grid-cols-1 md:grid-cols-3 items-center gap-6 md:gap-8"
        >
          {/* Bottom Left: Hint Button (tactile white 3D button) */}
          <div id="hint-button-container" className="w-full">
            <button
              id="btn-hint"
              onClick={handleHintClick}
              className={`w-full font-display font-black text-xl md:text-2xl uppercase tracking-wider bg-white text-[#202020] border-none rounded-[50px] shadow-[0_8px_0_#d9d9d9] hover:shadow-[0_4px_0_#d9d9d9] hover:translate-y-[4px] active:translate-y-[8px] active:shadow-none transition-all py-5 md:py-6 px-8 flex items-center justify-center gap-2 cursor-pointer ${
                hintOpen ? "ring-4 ring-orange-500/30" : ""
              }`}
            >
              <HelpCircle className="w-6 h-6 text-[#da8044]" />
              Hint
            </button>
          </div>

          {/* Bottom Middle: Stopwatch & Score board (Artistic styled) */}
          <div id="middle-status-container" className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Stopwatch
              seconds={timerSeconds}
              setSeconds={setTimerSeconds}
              isRunning={isTimerRunning}
            />

            {/* Score box */}
            <div
              id="score-tracker-badge"
              className="flex items-center gap-2 bg-white/10 border border-white/20 px-5 py-2.5 rounded-[20px] text-xs md:text-sm font-bold font-mono text-gray-200 shadow-md"
            >
              <Award className="w-4 h-4 text-[#da8044]" />
              <span>Score:</span>
              <span className="text-[#da8044] font-black">{scoreCorrect}</span>
              <span className="text-gray-400">/</span>
              <span>{scoreTotal}</span>
            </div>
          </div>

          {/* Bottom Right: Check (Controleer) Button (tactile orange 3D button) */}
          <div id="check-button-container" className="w-full">
            <button
              id="btn-controleer"
              onClick={handleCheckClick}
              disabled={!selectedCountry}
              className="w-full font-display font-black text-xl md:text-2xl uppercase tracking-wider bg-[#da8044] text-white border-none rounded-[50px] shadow-[0_8px_0_#b36430] hover:shadow-[0_4px_0_#b36430] hover:translate-y-[4px] active:translate-y-[8px] active:shadow-none disabled:bg-gray-700 disabled:text-gray-500 disabled:shadow-none disabled:translate-y-0 transition-all py-5 md:py-6 px-8 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-6 h-6" />
              Controleer
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
