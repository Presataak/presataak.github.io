import { CheckCircle2, AlertCircle, RefreshCw, ChevronRight, Globe } from "lucide-react";
import { Country, CountryDetails } from "../types";

interface StatusScreensProps {
  isCorrect: boolean | null; // true = Goed gedaan, false = Helaas fout
  targetCountry: Country;
  clickedCountryName: string | null;
  details: CountryDetails | null;
  onNext: () => void;
  onRetry: () => void;
  onOther: () => void;
}

export default function StatusScreens({
  isCorrect,
  targetCountry,
  clickedCountryName,
  details,
  onNext,
  onRetry,
  onOther,
}: StatusScreensProps) {
  if (isCorrect === null) return null;

  if (isCorrect) {
    return (
      <div
        id="status-correct-overlay"
        className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300"
      >
        <div
          id="status-correct-card"
          className="bg-white text-[#202020] w-full max-w-md rounded-[40px] p-6 md:p-8 text-center border-4 border-emerald-500 shadow-2xl scale-in"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-100 rounded-full mb-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-500" />
          </div>

          <h2 id="correct-title" className="font-display text-3xl md:text-4xl font-black text-emerald-600 uppercase tracking-tight mb-2">
            Goed gedaan!
          </h2>

          <p id="correct-subtitle" className="font-sans text-base md:text-lg font-bold text-gray-700 mb-4">
            Je hebt <span className="text-[#da8044] font-black">{targetCountry.dutchName}</span> correct aangewezen!
          </p>

          {details && details.funFact && (
            <div id="correct-fact" className="bg-orange-50 border-2 border-[#da8044]/20 rounded-[24px] p-4 mb-6 text-left relative overflow-hidden">
              <div className="absolute top-2 right-2 opacity-10">
                <Globe className="w-12 h-12 text-[#da8044]" />
              </div>
              <h4 className="font-display text-xs font-black text-[#da8044] uppercase tracking-widest mb-1">
                Leuk Weetje
              </h4>
              <p className="font-sans text-sm font-semibold leading-relaxed text-gray-800">
                {details.funFact}
              </p>
            </div>
          )}

          <button
            id="correct-next-btn"
            onClick={onNext}
            className="w-full font-display font-black text-lg uppercase tracking-wider bg-[#da8044] text-white rounded-[50px] shadow-[0_8px_0_#b36430] hover:shadow-[0_4px_0_#b36430] hover:translate-y-[4px] active:translate-y-[8px] active:shadow-none transition-all py-4 md:py-5 px-6 flex items-center justify-center gap-2 cursor-pointer group"
          >
            Volgende opdracht
            <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    );
  } else {
    return (
      <div
        id="status-incorrect-overlay"
        className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300"
      >
        <div
          id="status-incorrect-card"
          className="bg-white text-[#202020] w-full max-w-md rounded-[40px] p-6 md:p-8 text-center border-4 border-rose-500 shadow-2xl scale-in"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-rose-100 rounded-full mb-4">
            <AlertCircle className="w-12 h-12 text-rose-500" />
          </div>

          <h2 id="incorrect-title" className="font-display text-3xl md:text-4xl font-black text-rose-600 uppercase tracking-tight mb-2">
            Helaas fout!
          </h2>

          <p id="incorrect-subtitle" className="font-sans text-base md:text-lg font-bold text-gray-700 mb-6">
            {clickedCountryName ? (
              <>
                Je wees <span className="font-black text-[#da8044]">{clickedCountryName}</span> aan in plaats van <span className="font-black text-emerald-600">{targetCountry.dutchName}</span>.
              </>
            ) : (
              <>
                Je hebt geen land geselecteerd op de kaart. Probeer op een land te klikken!
              </>
            )}
          </p>

          <div id="incorrect-actions" className="flex flex-col gap-5">
            <button
              id="incorrect-retry-btn"
              onClick={onRetry}
              className="w-full font-display font-black text-lg uppercase tracking-wider bg-[#da8044] text-white rounded-[50px] shadow-[0_8px_0_#b36430] hover:shadow-[0_4px_0_#b36430] hover:translate-y-[4px] active:translate-y-[8px] active:shadow-none transition-all py-4 md:py-5 px-6 flex items-center justify-center gap-2 cursor-pointer"
            >
              <RefreshCw className="w-5 h-5 animate-spin-reverse" />
              Opnieuw proberen
            </button>

            <button
              id="incorrect-other-btn"
              onClick={onOther}
              className="w-full font-display font-black text-base uppercase tracking-wider bg-[#202020] text-white rounded-[50px] shadow-[0_8px_0_#151515] hover:shadow-[0_4px_0_#151515] hover:translate-y-[4px] active:translate-y-[8px] active:shadow-none transition-all py-3.5 px-6 flex items-center justify-center gap-2 cursor-pointer"
            >
              Andere opdracht
            </button>
          </div>
        </div>
      </div>
    );
  }
}
