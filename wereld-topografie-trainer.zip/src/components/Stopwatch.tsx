import { useEffect, Dispatch, SetStateAction } from "react";
import { Timer } from "lucide-react";

interface StopwatchProps {
  seconds: number;
  setSeconds: Dispatch<SetStateAction<number>>;
  isRunning: boolean;
}

export default function Stopwatch({ seconds, setSeconds, isRunning }: StopwatchProps) {
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setSeconds((prev) => {
        if (prev >= 3599) {
          // Hit 59:59, stop incrementing
          clearInterval(interval);
          return 3599;
        }
        return prev + 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, setSeconds]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div
      id="stopwatch-container"
      className="flex items-center justify-center gap-3 bg-white/10 border-2 border-white/20 px-6 py-3 rounded-[30px] text-white font-display text-2xl md:text-3xl font-black tracking-widest shadow-md"
    >
      <Timer id="stopwatch-icon" className="w-6 h-6 text-[#da8044] animate-pulse flex-shrink-0" />
      <span id="stopwatch-time">{formatTime(seconds)}</span>
    </div>
  );
}
