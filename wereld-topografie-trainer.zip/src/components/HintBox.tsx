import { X, Lightbulb, MapPin, ExternalLink } from "lucide-react";
import { HintType } from "../types";

interface HintBoxProps {
  hintType: HintType | null;
  hintValue: string | null;
  loading: boolean;
  onClose: () => void;
  sources?: Array<{ title: string; url: string }>;
}

export default function HintBox({ hintType, hintValue, loading, onClose, sources }: HintBoxProps) {
  if (!hintType) return null;

  const getHintText = () => {
    if (loading) {
      return "Hint laden met Google Maps...";
    }
    if (!hintValue) {
      return "Geen hint beschikbaar.";
    }

    switch (hintType) {
      case "continent":
        return `Het land ligt in ${hintValue}`;
      case "temperature":
        return `Het land is ${hintValue}`;
      case "location":
        return `Het land is ${hintValue} op de kaart`;
      case "size":
        return `Het land is ${hintValue}`;
      default:
        return hintValue;
    }
  };

  return (
    <div
      id="hint-box-container"
      onMouseDown={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      className="absolute bottom-24 left-6 z-50 max-w-sm w-[calc(100%-3rem)] md:w-[340px] bg-white text-[#202020] border-l-[12px] border-l-[#da8044] rounded-[30px] p-6 shadow-[0_20px_40px_rgba(0,0,0,0.5)] animate-in fade-in slide-in-from-bottom-5 duration-300"
    >
      <div id="hint-box-header" className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-6 h-6 text-[#da8044] fill-[#da8044]/10" />
          <h3 className="font-display text-sm font-black uppercase tracking-wider text-[#da8044]">
            Tip voor jou
          </h3>
        </div>
        <button
          id="hint-close-button"
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="w-8 h-8 rounded-full bg-[#f3f3f3] hover:bg-[#da8044] hover:text-white flex items-center justify-center font-bold text-gray-500 transition-colors cursor-pointer"
          aria-label="Sluit tip"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div id="hint-box-body" className="mb-3">
        <p id="hint-text" className="font-sans text-lg font-bold leading-relaxed text-[#202020]">
          {getHintText()}
        </p>
      </div>

      {sources && sources.length > 0 && (
        <div id="hint-sources" className="mt-3 border-t border-gray-100 pt-3">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">
            Google Maps Bronnen:
          </span>
          <div className="flex flex-col gap-1.5 max-h-16 overflow-y-auto">
            {sources.map((src, i) => (
              <a
                key={i}
                href={src.url}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-[#da8044] hover:underline flex items-center gap-1 font-bold truncate"
              >
                <MapPin className="w-3.5 h-3.5 text-orange-400 flex-shrink-0" />
                <span className="truncate">{src.title}</span>
                <ExternalLink className="w-2.5 h-2.5 flex-shrink-0" />
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
