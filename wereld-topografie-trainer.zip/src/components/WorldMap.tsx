import { useEffect, useState, useRef, MouseEvent, TouchEvent } from "react";
import { geoMercator, geoPath } from "d3-geo";
import { ZoomIn, ZoomOut, Compass, Loader2, Navigation, AlertTriangle } from "lucide-react";
import { getCountryByCode } from "../countries";
import { Country } from "../types";

interface WorldMapProps {
  selectedCountryId: string | null;
  onSelectCountry: (country: Country | null) => void;
  targetCountry: Country;
}

// Robust ID parser helper to resolve standard ISO codes from different GeoJSON property formats
export const getFeatureId = (feature: any): string => {
  if (!feature) return "";
  const props = feature.properties || {};
  
  // List of potential ID/code fields to try in order of preference
  const candidates = [
    props["iso-a3"],
    props.iso_a3,
    props.ISO_A3,
    props.iso_a3_eh,
    props.ISO_A3_EH,
    props["hc-key"],
    props.iso_a2,
    props.iso_a2_eh,
    props.ISO_A2,
    feature.id,
    props.id,
    props.name,
    props.NAME,
    props.name_en,
    props.name_sort
  ];

  for (const val of candidates) {
    if (val !== undefined && val !== null) {
      const str = val.toString().trim().toUpperCase();
      // Ignore placeholders like "-99", empty strings, or numeric placeholders that aren't real IDs
      if (str && str !== "-99" && str !== "99" && str !== "UNDEFINED" && str !== "-99.0" && str !== "NULL") {
        return str;
      }
    }
  }

  return "";
};

// Returns a beautiful, hand-painted style color based on geographic/climatic zones
export const getFeatureColor = (feature: any): string => {
  const rawId = getFeatureId(feature);
  const countryObj = getCountryByCode(rawId);
  const id = (countryObj?.id || rawId || "").toUpperCase();

  // Desert/Sandy zones (Warm Desert Sand)
  const desertIds = [
    "SAU", "EGY", "MAR", "IRN", "IRQ", "KAZ", "PAK", "DZA", "LBY", "SDN", "OMN", "YEM", "MRT", 
    "NER", "CHA", "MLI", "KWT", "QAT", "ARE", "TUN", "JOR", "SYR", "AFG", "TKM", "UZB", "MNG", 
    "NAM", "SOM", "AUS" // Australia has massive sandy desert outback!
  ];
  
  // Lush Nature zones (Rich Forest Greens)
  const greenIds = [
    "BRA", "COL", "IDN", "KEN", "NLD", "DEU", "BEL", "FRA", "CAN", "VNM", "THA", "MYS", "PHL", 
    "GBR", "NOR", "SWE", "FIN", "RUS", "COD", "COG", "CMR", "GAB", "ECU", "PER", "BOL", "VEN", 
    "SUR", "GUF", "GUY", "CRI", "PAN", "HND", "NIC", "GTM", "SLV", "BLZ", "NZL", "IRL", "DNK", 
    "AUT", "CHE"
  ];
  
  // Clay / Terracotta zones (Earth colors)
  const clayIds = [
    "USA", "ARG", "CHL", "ZAF", "MEX", "IND", "CHN", "ESP", "ITA", "GRC", "TUR", "UKR", "POL", 
    "ROU", "BGR", "KOR", "PRT", "ISL", "GRL"
  ];

  if (desertIds.includes(id)) {
    return "#dfb15b"; // Warm Desert Sand
  }
  if (greenIds.includes(id)) {
    return "#517e43"; // Lush Nature Green
  }
  if (clayIds.includes(id)) {
    return "#c97f53"; // Terracotta / Earth Clay
  }

  // Fallback soft parchment land color
  return "#ebd1b4";
};

export default function WorldMap({
  selectedCountryId,
  onSelectCountry,
  targetCountry,
}: WorldMapProps) {
  const [geoData, setGeoData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Zoom & Pan state
  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  
  // Tooltip & Hover state
  const [hoveredCountry, setHoveredCountry] = useState<Country | null>(null);

  const mapRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Fetch World GeoJSON on mount
  useEffect(() => {
    // Standard WGS84 GeoJSON: incredibly complete, contains Australia, Argentina, and all countries in true longitude/latitude coordinates.
    const PRIMARY_GEOJSON_URL = "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson";
    const FALLBACK_GEOJSON_URL = "https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json";

    setLoading(true);
    fetch(PRIMARY_GEOJSON_URL)
      .then((res) => {
        if (!res.ok) throw new Error("Primary URL failed.");
        return res.json();
      })
      .then((data) => {
        setGeoData(data);
        setLoading(false);
      })
      .catch((err) => {
        console.warn("Fout bij laden van primaire wereldkaart, proberen fallback...", err);
        fetch(FALLBACK_GEOJSON_URL)
          .then((res2) => {
            if (!res2.ok) throw new Error("Fallback kaart laden mislukt.");
            return res2.json();
          })
          .then((fallbackData) => {
            setGeoData(fallbackData);
            setLoading(false);
          })
          .catch((err2) => {
            setError("Kon de wereldkaart niet laden. Controleer je internetverbinding.");
            setLoading(false);
          });
      });
  }, []);

  // Dimensions of SVG
  const width = 800;
  const height = 450;

  // Setup D3 Mercator Projection
  const projection = geoMercator()
    .scale(120)
    .translate([width / 2, height / 1.6]);

  const pathGenerator = geoPath().projection(projection);

  // Floating Actions: Zoom In, Zoom Out, Reset
  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev * 1.4, 12));
  };

  const handleZoomOut = () => {
    setScale((prev) => Math.max(prev / 1.4, 1));
  };

  const handleReset = () => {
    setScale(1);
    setPan({ x: 0, y: 0 });
  };

  // Non-passive wheel zoom listener to allow preventDefault to block body scrolling
  useEffect(() => {
    const svgEl = mapRef.current;
    if (!svgEl) return;

    const handleWheelCallback = (e: any) => {
      e.preventDefault();
      const zoomIntensity = 0.12;
      const delta = e.deltaY < 0 ? 1 + zoomIntensity : 1 - zoomIntensity;

      setScale((currScale) => {
        const newScale = Math.max(1, Math.min(currScale * delta, 12));
        const rect = svgEl.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        setPan((currPan) => {
          const svgMouseX = (mouseX - currPan.x) / currScale;
          const svgMouseY = (mouseY - currPan.y) / currScale;
          return {
            x: mouseX - svgMouseX * newScale,
            y: mouseY - svgMouseY * newScale,
          };
        });

        return newScale;
      });
    };

    svgEl.addEventListener("wheel", handleWheelCallback, { passive: false });
    return () => {
      svgEl.removeEventListener("wheel", handleWheelCallback);
    };
  }, [loading]);

  // Mouse Drag handlers for Panning
  const handleMouseDown = (e: MouseEvent<SVGSVGElement>) => {
    if (e.button !== 0) return; // Only left click drag
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: MouseEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Touch handlers for mobile pan
  const handleTouchStart = (e: TouchEvent<SVGSVGElement>) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    setIsDragging(true);
    setDragStart({ x: touch.clientX - pan.x, y: touch.clientY - pan.y });
  };

  const handleTouchMove = (e: TouchEvent<SVGSVGElement>) => {
    if (!isDragging || e.touches.length !== 1) return;
    const touch = e.touches[0];
    setPan({
      x: touch.clientX - dragStart.x,
      y: touch.clientY - dragStart.y,
    });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // Click on a country
  const handleCountryClick = (e: MouseEvent<SVGPathElement>, feature: any) => {
    e.stopPropagation();
    const rawId = getFeatureId(feature);
    const country = getCountryByCode(rawId);
    
    if (country) {
      if (selectedCountryId === country.id) {
        onSelectCountry(null); // toggle select
      } else {
        onSelectCountry(country);
      }
    } else {
      console.log("Onbekend land geklikt:", feature.properties?.name || feature.id);
    }
  };

  // Hover over country to show Tooltip
  const handleCountryEnter = (e: MouseEvent<SVGPathElement>, feature: any) => {
    const rawId = getFeatureId(feature);
    const country = getCountryByCode(rawId);
    if (country) {
      setHoveredCountry(country);
    }
  };

  const handleCountryLeave = () => {
    setHoveredCountry(null);
  };

  // Render Loading state
  if (loading) {
    return (
      <div
        id="map-loading"
        className="flex flex-col items-center justify-center h-full w-full bg-[#202020] text-white p-6 rounded-[40px] border border-white/5"
      >
        <Loader2 className="w-12 h-12 text-[#da8044] animate-spin mb-4" />
        <h3 className="text-xl font-bold tracking-wide">Wereldkaart laden...</h3>
        <p className="text-sm text-gray-400 mt-1">
          De interactieve topografie is bijna klaar om te spelen!
        </p>
      </div>
    );
  }

  // Render Error state
  if (error) {
    return (
      <div
        id="map-error"
        className="flex flex-col items-center justify-center h-full w-full bg-[#202020] text-white p-6 rounded-[40px] border border-rose-500/30"
      >
        <AlertTriangle className="w-12 h-12 text-rose-500 mb-4" />
        <h3 className="text-xl font-bold tracking-wide text-rose-400">Oeps, fout bij laden</h3>
        <p className="text-sm text-gray-400 mt-1 text-center max-w-md">
          {error}
        </p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      id="map-viewport-container"
      className="relative w-full h-full bg-[#2c6b9e] border-4 border-[#da8044] rounded-[40px] overflow-hidden select-none shadow-inner"
    >
      {/* Zoom / Pan Navigation Overlay Controls */}
      <div
        id="map-controls-overlay"
        className="absolute top-4 right-4 z-20 flex flex-col gap-2 bg-[#202020]/90 border border-[#da8044]/30 p-1.5 rounded-xl backdrop-blur-md shadow-lg"
      >
        <button
          id="btn-zoom-in"
          onClick={handleZoomIn}
          className="p-2.5 bg-white/5 hover:bg-[#da8044] hover:text-black rounded-lg transition-all text-white cursor-pointer active:scale-90"
          title="Zoom in"
        >
          <ZoomIn className="w-5 h-5" />
        </button>
        <button
          id="btn-zoom-out"
          onClick={handleZoomOut}
          className="p-2.5 bg-white/5 hover:bg-[#da8044] hover:text-black rounded-lg transition-all text-white cursor-pointer active:scale-90"
          title="Zoom uit"
        >
          <ZoomOut className="w-5 h-5" />
        </button>
        <button
          id="btn-zoom-reset"
          onClick={handleReset}
          className="p-2.5 bg-white/5 hover:bg-[#da8044] hover:text-black rounded-lg transition-all text-white cursor-pointer active:scale-90"
          title="Centreren / Herstellen"
        >
          <Compass className="w-5 h-5" />
        </button>
      </div>

      {/* Helper text on desktop */}
      <div
        id="map-instruction-tag"
        className="absolute top-4 left-4 z-10 pointer-events-none hidden md:flex items-center gap-1.5 bg-black/60 px-3 py-1.5 rounded-full border border-white/10 text-xs text-gray-300 backdrop-blur-sm"
      >
        <Navigation className="w-3.5 h-3.5 rotate-45 text-[#da8044]" />
        <span>Sleep om te bewegen • Scroll of knoppen om te zoomen</span>
      </div>

      {/* SVG Canvas Map */}
      <svg
        ref={mapRef}
        id="world-map-svg"
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-full cursor-grab active:cursor-grabbing outline-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Oceans / Backdrop */}
        <rect width={width} height={height} fill="#2c6b9e" />

        {/* Group with Zoom & Pan Transforms */}
        <g transform={`translate(${pan.x}, ${pan.y}) scale(${scale})`}>
          
          {/* Layer 1: Base Map (Background land colors) */}
          {geoData &&
            geoData.features.map((feature: any, idx: number) => {
              const rawId = getFeatureId(feature);
              const countryObj = getCountryByCode(rawId);
              
              const isSelected = countryObj && selectedCountryId === countryObj.id;
              const isHovered = countryObj && hoveredCountry?.id === countryObj.id;
              
              // Get beautiful regional earthy base colors
              let fill = getFeatureColor(feature);
              let stroke = "rgba(0, 0, 0, 0.22)"; // Soft contrast border
              let strokeWidth = "0.35";

              if (isSelected) {
                fill = "#da8044"; // Theme Orange
                stroke = "transparent"; // Drawn on overlay
              } else if (isHovered) {
                stroke = "transparent"; // Drawn on overlay
              }

              const path = pathGenerator(feature);
              if (!path) return null;

              return (
                <path
                  key={`base-${rawId}-${idx}`}
                  d={path}
                  fill={fill}
                  stroke={stroke}
                  strokeWidth={strokeWidth}
                  className="transition-all duration-150 cursor-pointer outline-none"
                  onClick={(e) => handleCountryClick(e, feature)}
                  onMouseEnter={(e) => handleCountryEnter(e, feature)}
                  onMouseLeave={handleCountryLeave}
                />
              );
            })}

          {/* Layer 2: Overlay for Selected or Hovered Countries */}
          {/* This guarantees their complete, unbroken borders are rendered beautifully on top of adjacent countries */}
          {geoData &&
            geoData.features.map((feature: any, idx: number) => {
              const rawId = getFeatureId(feature);
              const countryObj = getCountryByCode(rawId);
              if (!countryObj) return null;

              const isSelected = selectedCountryId === countryObj.id;
              const isHovered = hoveredCountry?.id === countryObj.id;

              if (!isSelected && !isHovered) return null;

              const path = pathGenerator(feature);
              if (!path) return null;

              let fill = "transparent";
              let stroke = "#202020";
              let strokeWidth = "0.5";

              if (isSelected) {
                fill = "#da8044"; // Solid orange selection color
                stroke = "#ffffff"; // Bold white border
                strokeWidth = "2";
              } else if (isHovered) {
                fill = "rgba(255, 255, 255, 0.18)"; // Slightly highlighted white overlay
                stroke = "#da8044"; // Beautiful orange hover border
                strokeWidth = "1.5";
              }

              return (
                <path
                  key={`overlay-${rawId}-${idx}`}
                  d={path}
                  fill={fill}
                  stroke={stroke}
                  strokeWidth={strokeWidth}
                  className="pointer-events-none transition-all duration-150 outline-none"
                />
              );
            })}
        </g>
      </svg>
    </div>
  );
}
